var searchData=
[
  ['afegeix_5fcluster_5fa_5ftaula',['afegeix_cluster_a_taula',['../class_cjt___clusters.html#a7dbd8ebc6216c29b71b833a042d5f68c',1,'Cjt_Clusters']]],
  ['afegeix_5fdistancia_5fbuida',['afegeix_distancia_buida',['../class_cjt___clusters.html#abfceaf9ecefaf3326a8b674fac81086d',1,'Cjt_Clusters']]],
  ['afegeix_5fdistancies',['afegeix_distancies',['../class_cjt___clusters.html#a400816c786bdc252ca170074154b3a6e',1,'Cjt_Clusters']]],
  ['afegeix_5ftaula_5fdistancies',['afegeix_taula_distancies',['../class_cjt__especies.html#a9a6c570cab200d4c7f4d65f101281cc1',1,'Cjt_especies']]]
];
