var searchData=
[
  ['gen',['gen',['../class_especie.html#ac35bb565f7346cd6317b3a8c849456d1',1,'Especie']]],
  ['gestió_20i_20creació_20d_27un_20arbre_20filogenètic',['Gestió i creació d&apos;un arbre filogenètic',['../index.html',1,'']]]
];
