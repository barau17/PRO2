var searchData=
[
  ['id',['id',['../class_especie.html#a91b94109fb8a456bba7199cdda36d588',1,'Especie']]],
  ['imprimeix_5farbre_5ffilogenetic',['imprimeix_arbre_filogenetic',['../class_cjt___clusters.html#ad4a2e86524df3f4c20ec8c65ab95f30c',1,'Cjt_Clusters']]],
  ['imprimeix_5fcjt_5fespecies',['imprimeix_cjt_especies',['../class_cjt__especies.html#a0cfad9b9ffbb0a648297c1b6057eab73',1,'Cjt_especies']]],
  ['imprimeix_5fcluster',['imprimeix_cluster',['../class_cjt___clusters.html#a33f5950254d3b5811f1f3781229e26d5',1,'Cjt_Clusters']]],
  ['imprimeix_5ftaula_5fdistancia',['imprimeix_taula_distancia',['../class_cjt___clusters.html#a00e6fb0ba010b809d92836555bf24b10',1,'Cjt_Clusters']]],
  ['inicialitza_5fclusters',['inicialitza_clusters',['../class_cjt__especies.html#a3a1323072480720134502760375b7cdd',1,'Cjt_especies']]]
];
