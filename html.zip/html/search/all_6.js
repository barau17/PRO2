var searchData=
[
  ['k',['k',['../class_cjt__especies.html#a57eaad8467ae4fef3aad9407a235bb3c',1,'Cjt_especies']]],
  ['kmers',['kmers',['../class_especie.html#a55f598539b21a0cd31d8254089b59e79',1,'Especie']]]
];
