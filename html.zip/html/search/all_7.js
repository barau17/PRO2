var searchData=
[
  ['llegeix_5fcjt_5fespecies',['llegeix_cjt_especies',['../class_cjt__especies.html#a4cfe2b5529cd5d96408d45dc39304175',1,'Cjt_especies']]],
  ['llegir',['llegir',['../class_especie.html#a7384add391d2684c4fb6bdf8a535fba3',1,'Especie']]],
  ['llegir_5fk',['llegir_k',['../class_cjt__especies.html#a4ead6b959e00ed84a03e298268dcf263',1,'Cjt_especies']]]
];
