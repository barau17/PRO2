var searchData=
[
  ['nova_5ftaula_5fdistancies',['nova_taula_distancies',['../class_cjt___clusters.html#ab58e7a1c04d4d61408ce8874f374ddfe',1,'Cjt_Clusters']]]
];
