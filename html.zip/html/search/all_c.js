var searchData=
[
  ['taula_5fde_5fdistancies',['taula_de_distancies',['../class_cjt__especies.html#a3872dd44680216af0d0e4c0ec1612a09',1,'Cjt_especies']]],
  ['taula_5fdistancies',['taula_distancies',['../class_cjt__especies.html#ad66ac0438cce1ecf2c5553cb98f1085a',1,'Cjt_especies']]],
  ['te_5fgen',['te_gen',['../class_especie.html#af4b3630a3e5b5e14505115d9a2493c3e',1,'Especie']]],
  ['tgen',['tgen',['../class_especie.html#a36fcef003529bb7b29420c4831ba0b6c',1,'Especie']]]
];
