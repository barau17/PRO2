var searchData=
[
  ['taula_5fdistancies',['taula_distancies',['../class_cjt__especies.html#ad66ac0438cce1ecf2c5553cb98f1085a',1,'Cjt_especies']]],
  ['te_5fgen',['te_gen',['../class_especie.html#af4b3630a3e5b5e14505115d9a2493c3e',1,'Especie']]]
];
