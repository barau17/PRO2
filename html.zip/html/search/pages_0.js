var searchData=
[
  ['gestió_20i_20creació_20d_27un_20arbre_20filogenètic',['Gestió i creació d&apos;un arbre filogenètic',['../index.html',1,'']]]
];
